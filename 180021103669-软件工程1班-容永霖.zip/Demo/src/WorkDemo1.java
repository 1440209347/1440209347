
import java.util.*;
public class WorkDemo1 {

	public static void main(String[] args) {
		Random r=new Random();
		int[] count=new int[11];
		
		for (int i = 1; i <= 5000; i++) {
			int n1=r.nextInt(6)+1;
			int n2=r.nextInt(6)+1;
			int sum=n1+n2;//sumȡֵΪ2-12
			count[sum-2]++;
			//count[0] �ǵ���֮��Ϊ2���ֵĴ���
			//count[10] �ǵ���֮��Ϊ12���ֵĴ���
		}
			for(int i=0;i<count.length;i++) {
				
	        System.out.println(i+2+":"+count[i]+"��");
    }
			System.out.println("Process completed.");
  }
}
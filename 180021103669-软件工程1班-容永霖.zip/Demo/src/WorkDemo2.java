
	import java.util.*;
	public class WorkDemo2 {

		public static void main(String[] args) {
			HashSet A=new HashSet();
			A.add(new Integer(1));
			A.add(new Integer(2));
			A.add(new Integer(3));
			A.add(new Integer(4));

			HashSet B=new HashSet();
			B.add(new Integer(1));
			B.add(new Integer(3));
			B.add(new Integer(7));
			B.add(new Integer(9));
			B.add(new Integer(11));
			
			HashSet C=(HashSet)A.clone();
			
			//�󲢼�
			A.addAll(B); //�Ѽ���B�ϲ���A������
			for(int i=0;i<A.size();i++) {
				if(!A.contains(B.getClass()))
					B.add(A.getClass());
			}
			System.out.println("A��B�Ĳ���:"+A);
			
			//�󽻼�
			A=(HashSet)C.clone();
			A.retainAll(B);//��A��B�Ľ���
			for(int i=0;i<A.size();i++) {
				if(!A.contains(B.getClass()))
					B.add(A.getClass());
			}
			System.out.println("A��B�Ľ���:"+A);
			
			//��
			A=(HashSet)C.clone();
			A.removeAll(B);
			for(int i=0;i<A.size();i++) {
				if(!A.contains(B.getClass()))
					B.add(A.getClass());
			}
			System.out.println("A��B�Ĳ:"+A);
		}

	}

